/**
 * User Routes Module (POST /report, GET /items, POST /claim, NEW: Profile Settings)
 * This version uses Mongoose for permanent storage, filtering, and status updates.
 */
const express = require('express');
const router = express.Router();
// Assuming a middleware to protect routes (like checking login status)
// ✅ Corrected line to match your file name (auth.js)
const { protect } = require('../middleware/auth'); // 💡 CHECK THIS PATH
const Item = require('../models/Item'); 

// 🚨 CRITICAL: You must ensure this file exists with a Mongoose Schema!
const User = require('../models/User'); 

// ==========================================================
// 🚨 NEW ROUTES FOR USER SETTINGS 🚨
// ==========================================================

/**
 * GET /api/user/settings/profile
 * Endpoint to load the current user's profile data.
 * The full URL is mounted as: /api/user + /settings/profile
 */
router.get('/settings/profile', protect, async (req, res) => {
    // 💡 IMPORTANT: Ensure req.user.id is correctly set by your 'protect' middleware.
    try {
        const user = await User.findById(req.user.id).select('-password'); // Exclude password
        
        // This check handles the previous "Error: Could not load profile data." if the user isn't found
        if (!user) {
            // Returning a 404 is technically correct if the resource (user) doesn't exist
            return res.status(404).json({ message: 'Error: Could not load profile data.' }); 
        }

        // Return the profile data. Ensure key names match your frontend form fields!
        res.status(200).json({
            fullName: user.fullName || '',
            email: user.email || '',
            phoneNumber: user.phoneNumber || '',
            organization: user.organization || ''
        });

    } catch (error) {
        console.error('Error loading user profile:', error.message);
        // If the ID format is bad, Mongoose throws a CastError, which is handled here as a 500
        res.status(500).json({ message: 'Internal server error while loading profile.' });
    }
});


/**
 * POST /api/user/settings/profile
 * Endpoint to update the current user's profile data.
 * This is the **MISSING** route that caused the 404 error! It is now correctly added.
 */
router.post('/settings/profile', protect, async (req, res) => {
    try {
        const { fullName, email, phoneNumber, organization } = req.body;

        // Get the user ID from the authentication middleware
        const user = await User.findById(req.user.id);
        
        if (!user) {
            // This case is unlikely if 'protect' ran, but good to check
            return res.status(404).json({ message: 'Error: User not found for update.' });
        }
        
        // Update fields: only use new value if provided, otherwise keep existing
        user.fullName = fullName !== undefined ? fullName : user.fullName;
        user.email = email !== undefined ? email : user.email;
        user.phoneNumber = phoneNumber !== undefined ? phoneNumber : user.phoneNumber;
        user.organization = organization !== undefined ? organization : user.organization;
        
        // Alternative Mongoose update (cleaner):
        // const updatedUser = await User.findByIdAndUpdate(req.user.id, req.body, { new: true });

        await user.save();

        // Respond with success
        res.status(200).json({ 
            message: 'Profile settings saved successfully.',
            user: {
                fullName: user.fullName,
                email: user.email,
                organization: user.organization
            } 
        });

    } catch (error) {
        console.error('CRITICAL DB ERROR processing profile update:', error.message);
        // Send a 500 if the database operation fails
        res.status(500).json({ message: `Internal server error during update: ${error.message}` });
    }
});

// ==========================================================
// EXISTING ROUTES BELOW 
// NOTE: I am including the body of the existing routes to ensure a complete file.
// ==========================================================


/**
 * POST /api/user/report
 * Endpoint to permanently store the lost item report in the database.
 */
router.post('/report', async (req, res) => {
    // Logging placed at the absolute top of the route execution
    console.log('--- REPORT ENDPOINT HIT (MongoDB Save) ---'); 

    // Destructure required fields from the request body
    const { title, description, location, contact, date, imageBase64, reporterName } = req.body;
    
    // Basic validation
    if (!title || !location || !date) {
        console.warn('Validation Failed: Missing required fields.');
        return res.status(400).json({ message: 'Missing required item details (Title, Location, and Date are mandatory).' });
    }

    try {
        let submissionDate = null;
        try {
            submissionDate = new Date(date);
            // Check if the date conversion resulted in a valid date
            if (isNaN(submissionDate.getTime())) {
                throw new Error("Invalid date format received.");
            }
        } catch (dateError) {
            console.error('Date parsing failed:', dateError.message);
            // Return 400 if the date is invalid, preventing Mongoose crash
            return res.status(400).json({ message: 'Invalid date format submitted.' });
        }


        // Prepare image if provided (expects data URL or raw base64)
        let imageUrl = null;
        try {
            if (imageBase64 && typeof imageBase64 === 'string' && imageBase64.length > 0) {
                const fs = require('fs');
                const path = require('path');

                // Ensure uploads directory exists
                const uploadsDir = path.join(__dirname, '..', 'public', 'uploads');
                if (!fs.existsSync(uploadsDir)) {
                    fs.mkdirSync(uploadsDir, { recursive: true });
                }

                // Strip possible data URL prefix
                const matches = imageBase64.match(/^data:(.*?);base64,(.*)$/);
                const base64Data = matches ? matches[2] : imageBase64;
                const mimeType = matches ? matches[1] : 'image/png';

                // Choose extension from mime type
                const ext = mimeType.includes('jpeg') || mimeType.includes('jpg') ? 'jpg'
                    : mimeType.includes('png') ? 'png'
                    : mimeType.includes('gif') ? 'gif'
                    : 'png';

                // Unique filename
                const filename = `item_${Date.now()}_${Math.round(Math.random()*1e6)}.${ext}`;
                const filePath = path.join(uploadsDir, filename);

                // Write file
                fs.writeFileSync(filePath, Buffer.from(base64Data, 'base64'));

                // Store relative URL to be served statically
                imageUrl = `/uploads/${filename}`;
            }
        } catch (imgErr) {
            console.error('Image save failed:', imgErr.message);
            // Do not fail the report if image fails; continue without image
        }

        // Log data *before* database operation
        console.log('Data received (pre-db):', { title, description, location, contact, date: submissionDate, imageUrl });
        
        // Create a new item document in MongoDB
        const newReport = await Item.create({
            title,
            description,
            location,
            contact,
            date: submissionDate, // Use the validated Date object
            imageUrl,
            reporterName,
        });

        console.log(`Report saved successfully. Item ID: ${newReport._id}`);
        
        // Respond with success message
        res.status(201).json({ 
            message: 'Item report received and saved successfully!',
            itemId: newReport._id 
        });

    } catch (error) {
        // Handle database errors or unexpected crashes
        console.error('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
        console.error('!!! SERVER CRASH LIKELY HERE: CRITICAL DB ERROR PROCESSING REPORT !!!');
        console.error('!!! ERROR:', error.message);
        console.error('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
        
        // This is what the client receives if the server crashes
        res.status(500).json({ message: `Internal server error during save: ${error.message}` });
    }
});

/**
 * POST /api/user/claim/:id
 * Endpoint to toggle the 'isClaimed' status of a specific item.
 * Requires the item ID in the URL and the new boolean status in the body.
 */
router.post('/claim/:id', async (req, res) => {
    try {
        const itemId = req.params.id;
        const { isClaimed } = req.body; // Expecting a boolean (true/false)

        if (typeof isClaimed !== 'boolean') {
            return res.status(400).json({ message: 'Invalid claim status provided (must be boolean).' });
        }
        
        // Find the item by ID and update the isClaimed status
        const updatedItem = await Item.findByIdAndUpdate(
            itemId,
            { isClaimed },
            { new: true } // Returns the updated document
        );

        if (!updatedItem) {
            return res.status(404).json({ message: 'Item not found.' });
        }

        res.status(200).json({ 
            message: `Item status updated to claimed: ${updatedItem.isClaimed}`,
            item: {
                id: updatedItem._id,
                isClaimed: updatedItem.isClaimed
            }
        });

    } catch (error) {
        console.error('CRITICAL DB ERROR processing claim update:', error.message);
        res.status(500).json({ message: `Internal server error during claim update: ${error.message}` });
    }
});


/**
 * GET /api/user/items
 * Endpoint to retrieve and filter reported items from the database.
 */
router.get('/items', async (req, res) => {
    console.log('--- ITEMS ENDPOINT HIT (MongoDB Fetch) ---');
    
    try {
        const { query } = req.query; // Get the search term from the URL query parameters
        let filter = {};

        if (query) {
            console.log(`Filtering items by search term: "${query}"`);
            
            // Create a MongoDB filter using $regex for case-insensitive partial matching
            const searchRegex = new RegExp(query, 'i');
            
            // Search across the title and location fields
            filter = {
                $or: [
                    { title: { $regex: searchRegex } },
                    { location: { $regex: searchRegex } }
                ]
            };
        }

        // Retrieve items from the database, applying the filter and sorting by newest first
        const items = await Item.find(filter).sort({ reportedAt: -1 });

        console.log(`Serving ${items.length} items from MongoDB.`);
        
        // Map Mongoose documents to plain objects for the client
        const sanitizedItems = items.map(item => ({
            id: item._id, 
            title: item.title,
            description: item.description,
            location: item.location,
            contact: item.contact,
            isClaimed: item.isClaimed || false, // <-- NEW: Include claim status
            imageUrl: item.imageUrl || null,
            reporterName: item.reporterName || null,
            // Format the date for cleaner display on the client side
            date: item.date ? item.date.toISOString().split('T')[0] : 'N/A' 
        }));

        res.status(200).json(sanitizedItems);

    } catch (error) {
        // Handle database errors or unexpected crashes
        console.error('SERVER CATCH: Critical DB Error fetching reports:', error.message, error.stack);
        res.status(500).json({ message: `Internal server error during fetch: ${error.message}` });
    }
});


module.exports = router;