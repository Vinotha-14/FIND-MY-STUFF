// routes/admin.js

/**
 * Admin Routes Module (Example: GET /users, POST /item/approve)
 * These routes should be heavily protected, only accessible by users with the 'admin' role.
 */
const express = require('express');
const router = express.Router();
const Item = require('../models/Item');
const User = require('../models/User');

// 🚨 CRITICAL: You MUST create this new middleware!
// This middleware must check if the user is logged in AND has the role 'admin'.
const { protectAdmin } = require('../middleware/auth'); // 💡 CHECK THIS PATH

// ==========================================================
// ADMIN DASHBOARD ROUTES
// ==========================================================

/**
 * GET /api/admin/dashboard-stats
 * Example: Load data for the admin dashboard overview.
 */
router.get('/dashboard-stats', protectAdmin, async (req, res) => {
    try {
        // Example logic: Fetch total counts for items and users
        const totalItems = await Item.countDocuments();
        const claimedItems = await Item.countDocuments({ isClaimed: true });
        const totalUsers = await User.countDocuments();

        res.status(200).json({
            totalItems,
            claimedItems,
            totalUsers,
            message: 'Admin dashboard stats loaded successfully.'
        });
    } catch (error) {
        console.error('Error fetching admin stats:', error.message);
        res.status(500).json({ message: 'Internal server error while loading admin stats.' });
    }
});

/**
 * GET /api/admin/users
 * Example: Load a list of all users for admin management.
 */
router.get('/users', protectAdmin, async (req, res) => {
    try {
        // Fetch all users, excluding their password hash
        const users = await User.find().select('-password'); 

        res.status(200).json(users);
    } catch (error) {
        console.error('Error fetching all users:', error.message);
        res.status(500).json({ message: 'Internal server error while fetching users.' });
    }
});


// NOTE: You can also move the GET /items route here if you want to apply
// admin-only filters, but for simple fetching, keeping it in routes/user.js is fine.


module.exports = router;