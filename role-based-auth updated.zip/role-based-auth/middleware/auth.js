// middleware/auth.js

const jwt = require('jsonwebtoken');

// 💡 CHANGE: Exporting the function as 'protect' to match the import 
// statement in routes/user.js: const { protect } = require('../middleware/authMiddleware'); 
function protect(req, res, next) {
    try {
        // 1. Check for token in cookies
        const token = req.cookies?.token;
        if (!token) {
            return res.status(401).json({ message: 'No token, authorization denied' });
        }

        // 2. Verify token
        // Ensure you have JWT_SECRET defined in your .env file
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        
        // 3. Attach user data to the request object (CRITICAL STEP for routes/user.js)
        // This ensures req.user.id is available in the profile settings routes.
        req.user = { 
            id: decoded.id, 
            roles: decoded.roles || [] 
        };
        
        // 4. Continue to the next middleware/route handler
        next();
        
    } catch (err) {
        // Handle verification failure (e.g., expired or malformed token)
        console.error('JWT verification failed:', err.message);
        return res.status(401).json({ message: 'Token invalid or expired' });
    }
}

// 💡 CHANGE: Export 'protect' (or whatever name you choose)
module.exports = { protect };