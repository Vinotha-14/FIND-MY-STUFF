/**
 * Client-side script for the User Dashboard (Find My Stuff)
 * This script handles:
 * 1. Navigation between dashboard sections and visual highlighting.
 * 2. Intercepting the Report Lost Item form submission (POST /api/user/report).
 * 3. Fetching and displaying reported items in the Search Items section (GET /api/user/items?query=...).
 * 4. Handling the Claim Items list and status toggling (POST /api/user/claim/:id).
 * 5. Fetching and updating user profile settings, including Full Name, Email, Phone, and Organization (GET/POST /api/user/settings/profile).
 * 6. Handling the user logout process (POST /api/auth/logout). 
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initial Setup: Show the default section and highlight the button
    const initialButton = document.getElementById('nav-report');
    showSection('report', initialButton);
    
    // 2. Set up Navigation Button Listeners
    document.querySelectorAll('#mainNav button').forEach(button => {
        button.addEventListener('click', function() {
            // Extract sectionId from button id (e.g., 'nav-report' -> 'report')
            const sectionId = button.id.replace('nav-', '');
            showSection(sectionId, button);
        });
    });

    // 3. Set up the Report Form Submission Listener
    const reportForm = document.getElementById('reportForm');
    if (reportForm) {
        reportForm.addEventListener('submit', handleReportSubmission);
    }
    
    // 4. Set up the Search button listener (Assuming you add id="searchButton" to your search button)
    const searchButton = document.getElementById('searchButton');
    if(searchButton) {
        searchButton.addEventListener('click', searchItems);
    }

    // 5. Set up the Settings Form Submission Listener
    const settingsForm = document.getElementById('settingsForm');
    if(settingsForm) {
        settingsForm.addEventListener('submit', handleSettingsUpdate);
    }
    
    // 6. Set up the Logout Button Listener 
    const logoutButton = document.getElementById('logoutButton');
    if (logoutButton) {
        logoutButton.addEventListener('click', handleLogout);
    }
});

/**
 * Handles the user logout process by clearing the token cookie.
 */
async function handleLogout() {
    // Optional: Add a confirmation dialog for better UX
    if (!confirm('Are you sure you want to log out?')) {
        return;
    }

    try {
        const response = await fetch('/api/auth/logout', {
            method: 'POST',
            // Server clears the token cookie; no body needed.
        });

        if (response.ok) {
            // Success: Redirect the user to the login page (index.html)
            window.location.href = '/index.html'; 
        } else {
            // Handle server-side errors
            alert('Logout failed. Please try again.');
            console.error('Logout failed:', response.status);
        }
    } catch (error) {
        // Handle network errors
        console.error('Network error during logout:', error);
        alert('A network error occurred during logout.');
    }
}

/**
 * Handles navigation between dashboard sections and updates active button styles.
 * @param {string} sectionId - The ID of the section to show.
 * @param {HTMLElement | null} activeButton - The navigation button element that was clicked.
 */
function showSection(sectionId, activeButton = null) {
    // 1. Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.style.display = 'none';
    });
    const target = document.getElementById(sectionId);
    if (target) {
        target.style.display = 'block';
    }
    
    // 2. Update Nav Button Styles (Tailwind classes)
    document.querySelectorAll('#mainNav button').forEach(button => {
        // Reset all buttons to inactive style
        button.classList.remove('bg-blue-600', 'text-white', 'hover:bg-blue-700');
        button.classList.add('bg-gray-200', 'text-gray-700', 'hover:bg-gray-300');
    });

    if (activeButton) {
        // Set the active button style
        activeButton.classList.remove('bg-gray-200', 'text-gray-700', 'hover:bg-gray-300');
        activeButton.classList.add('bg-blue-600', 'text-white', 'hover:bg-blue-700');
    }
    
    // 3. Trigger content loads based on section
    if (sectionId === 'claim') {
        loadClaimItems();
    }
    if (sectionId === 'settings') { 
        loadUserSettings();
    }
}

/**
 * Handles the API call for reporting a lost item.
 * @param {Event} event - The submission event.
 */
async function handleReportSubmission(event) {
    event.preventDefault(); 

    const form = event.target;
    const messageEl = document.getElementById('reportMessage') || createMessageElement(form, 'reportMessage');
    
    messageEl.style.display = 'none';
    messageEl.classList.add('mt-4', 'p-3', 'rounded', 'text-center', 'font-medium'); 

    const itemData = {
        title: document.getElementById('itemTitle').value, 
        description: document.getElementById('description').value,
        location: document.getElementById('location').value,
        contact: document.getElementById('contact').value, 
        date: document.getElementById('date').value,
    };

    try {
        const response = await fetch('/api/user/report', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(itemData)
        });

        if (response.ok) {
            const result = await response.json();
            messageEl.textContent = '✅ Item successfully reported! ID: ' + result.itemId;
            messageEl.classList.remove('bg-red-200', 'text-red-700');
            messageEl.classList.add('bg-green-200', 'text-green-700');
            form.reset(); 
            searchItems(); 
        } else {
            let errorText = 'Unknown Error.';
            try {
                const errorJson = await response.json();
                errorText = errorJson.message || `Server responded with status ${response.status}`;
            } catch {
                errorText = `Server responded with status ${response.status}`;
            }
            
            console.error('Submission failed. Server response:', response.status, errorText);
            messageEl.textContent = `❌ Error: ${errorText}`;
            messageEl.classList.remove('bg-green-200', 'text-red-700');
            messageEl.classList.add('bg-red-200', 'text-red-700');
        }

    } catch (error) {
        if (!messageEl.textContent.startsWith('❌ Error:')) {
            console.error('Submission failed (Network/Catch):', error);
            messageEl.textContent = '❌ Network Error: Could not connect to server.';
            messageEl.classList.remove('bg-green-200', 'text-red-700');
            messageEl.classList.add('bg-red-200', 'text-red-700');
        }
    } finally {
        messageEl.style.display = 'block';
    }
}

/**
 * Fetches and displays reported items in the Search Items section, filtering by search query.
 */
async function searchItems() {
    const resultsDiv = document.getElementById('results');
    const searchQuery = document.getElementById('searchQuery').value.trim();
    
    const apiUrl = searchQuery ? `/api/user/items?query=${encodeURIComponent(searchQuery)}` : '/api/user/items';

    resultsDiv.innerHTML = '<p class="text-center text-gray-500 py-4">Searching for items...</p>';
    
    try {
        const response = await fetch(apiUrl);
        if (!response.ok) {
            throw new Error('Failed to fetch items.');
        }

        const items = await response.json();

        if (items.length === 0) {
            resultsDiv.innerHTML = `<p class="text-center text-gray-400 py-4">No lost items found matching "${searchQuery}".</p>`;
            return;
        }
        
        // Note: The toggleClaimStatus function still uses inline onclick for simplicity in this generated list.
        resultsDiv.innerHTML = items.map(item => `
            <div class="item-card bg-white p-4 rounded-xl shadow-md border-l-4 ${item.isClaimed ? 'border-green-500' : 'border-red-500'}">
                <div class="flex justify-between items-center mb-2">
                    <h3 class="text-xl font-bold text-gray-800">${item.title}</h3>
                    <span class="text-sm font-semibold ${item.isClaimed ? 'text-green-600' : 'text-red-600'}">
                        ${item.isClaimed ? 'CLAIMED' : 'UNCLAIMED'}
                    </span>
                </div>
                <p class="text-sm text-gray-600 mb-1"><strong>📍 Location:</strong> ${item.location}</p>
                <p class="text-sm text-gray-600 mb-1"><strong>📞 Contact:</strong> ${item.contact || 'N/A'}</p>
                <p class="text-sm text-gray-600"><strong>📅 Date Lost:</strong> ${item.date}</p>
                <p class="text-xs text-gray-500 italic mt-2">Description: ${item.description || 'No description provided.'}</p>
            </div>
        `).join('');

    } catch (error) {
        console.error('Error fetching items:', error);
        resultsDiv.innerHTML = '<p class="text-center text-red-500 py-4">Error loading items. Please check server status.</p>';
    }
}

/**
 * Fetches and displays reported items specifically for the Claim/Manage section.
 */
async function loadClaimItems() {
    const claimListDiv = document.getElementById('claimList');
    claimListDiv.innerHTML = '<p class="text-center text-gray-500 py-4">Loading reported items...</p>';

    try {
        const response = await fetch('/api/user/items');
        if (!response.ok) {
            throw new Error('Failed to fetch items for claiming.');
        }

        const items = await response.json();

        if (items.length === 0) {
            claimListDiv.innerHTML = `<p class="text-center text-gray-400 py-4">No items have been reported yet.</p>`;
            return;
        }
        
        // Note: The toggleClaimStatus function still uses inline onclick for simplicity in this generated list.
        claimListDiv.innerHTML = items.map(item => `
            <div id="item-${item.id}" class="item-card flex flex-col md:flex-row justify-between items-start md:items-center bg-white p-4 rounded-xl shadow border-l-4 ${item.isClaimed ? 'border-green-500' : 'border-red-500'}">
                <div class="flex-grow mb-3 md:mb-0">
                    <h3 class="text-lg font-bold text-gray-800">${item.title}</h3>
                    <p class="text-xs text-gray-500">ID: ${item.id}</p>
                    <p class="text-sm text-gray-600 mt-1">📍 ${item.location} | 📅 ${item.date}</p>
                </div>
                
                <div class="claim-status-group flex flex-col items-start md:items-end space-y-2">
                    <span id="status-label-${item.id}" class="text-sm font-extrabold ${item.isClaimed ? 'text-green-600' : 'text-red-600'}">
                        ${item.isClaimed ? 'CLAIMED' : 'UNCLAIMED'}
                    </span>
                    <button 
                        data-id="${item.id}" 
                        data-claimed="${item.isClaimed}"
                        onclick="toggleClaimStatus('${item.id}', ${item.isClaimed})"
                        class="py-2 px-4 rounded-lg font-semibold text-white transition duration-150 shadow-md 
                        ${item.isClaimed ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600'}">
                        ${item.isClaimed ? 'Mark as UNCLAIMED' : 'Mark as CLAIMED'}
                    </button>
                </div>
            </div>
        `).join('');

    } catch (error) {
        console.error('Error fetching items for claiming:', error);
        claimListDiv.innerHTML = '<p class="text-center text-red-500 py-4">Error loading claim list. Please check server status.</p>';
    }
}

/**
 * Toggles the 'isClaimed' status of an item via a POST request to the server.
 */
async function toggleClaimStatus(itemId, currentStatus) {
    const newStatus = !currentStatus;
    const button = document.querySelector(`button[data-id="${itemId}"]`);
    const statusLabel = document.getElementById(`status-label-${itemId}`);

    if (button) {
        button.disabled = true; 
        button.textContent = 'Updating...';
    }

    try {
        const response = await fetch(`/api/user/claim/${itemId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ isClaimed: newStatus })
        });

        if (response.ok) {
            const responseData = await response.json();
            const claimed = responseData.item.isClaimed;

            if (button) {
                button.setAttribute('data-claimed', claimed);
                button.textContent = claimed ? 'Mark as UNCLAIMED' : 'Mark as CLAIMED';
                
                if (claimed) {
                    button.classList.remove('bg-green-500', 'hover:bg-green-600');
                    button.classList.add('bg-red-500', 'hover:bg-red-600');
                } else {
                    button.classList.remove('bg-red-500', 'hover:bg-red-600');
                    button.classList.add('bg-green-500', 'hover:bg-green-600');
                }
            }
            if (statusLabel) {
                statusLabel.textContent = claimed ? 'CLAIMED' : 'UNCLAIMED';
                
                if (claimed) {
                    statusLabel.classList.remove('text-red-600');
                    statusLabel.classList.add('text-green-600');
                } else {
                    statusLabel.classList.remove('text-green-600');
                    statusLabel.classList.add('text-red-600');
                }
            }
            const card = document.getElementById(`item-${itemId}`);
            if (card) {
                card.classList.remove('border-green-500', 'border-red-500');
                card.classList.add(claimed ? 'border-green-500' : 'border-red-500');
            }


        } else {
            const error = await response.json();
            console.error('Failed to update status:', error.message);
            console.error(`ERROR: Failed to update status: ${error.message}`); 
        }
    } catch (error) {
        console.error('Network error during status toggle:', error);
        console.error('ERROR: Network Error: Could not connect to the server to update status.');
    } finally {
        if (button) {
            button.disabled = false;
        }
    }
}

/**
 * Fetches the user's current profile settings and populates the form.
 * 💡 CRITICAL FIX: Uses 'fullName' and 'phoneNumber' to match backend.
 */
async function loadUserSettings() {
    const settingsMessage = document.getElementById('settingsMessage');
    const form = document.getElementById('settingsForm');
    
    settingsMessage.style.display = 'none';
    form.classList.add('opacity-50', 'pointer-events-none'); // Disable form while loading

    try {
        const response = await fetch('/api/user/settings/profile');
        if (!response.ok) {
            throw new Error('Failed to fetch user profile.');
        }

        const user = await response.json();
        
        // Use 'fullName' and 'phoneNumber' from the backend response
        document.getElementById('settingName').value = user.fullName || ''; 
        document.getElementById('settingEmail').value = user.email || '';
        document.getElementById('settingPhone').value = user.phoneNumber || ''; 
        document.getElementById('settingOrganization').value = user.organization || ''; 
        
        // Update the welcome message
        document.getElementById('username').textContent = user.fullName || 'User'; 

    } catch (error) {
        console.error('Error loading user settings:', error);
        settingsMessage.textContent = '❌ Error: Could not load profile data.'; 
        settingsMessage.classList.remove('bg-green-200', 'text-green-700');
        settingsMessage.classList.add('bg-red-200', 'text-red-700');
        settingsMessage.style.display = 'block';
    } finally {
        form.classList.remove('opacity-50', 'pointer-events-none'); // Re-enable form
    }
}

/**
 * Handles the submission to update user profile settings.
 * 💡 CRITICAL FIX: Sends data using 'fullName' and 'phoneNumber' to match backend.
 * @param {Event} event - The submission event.
 */
async function handleSettingsUpdate(event) {
    event.preventDefault();

    const form = event.target;
    const messageEl = document.getElementById('settingsMessage') || createMessageElement(form, 'settingsMessage');
    const submitButton = form.querySelector('button[type="submit"]');

    messageEl.style.display = 'none';
    messageEl.classList.add('mt-4', 'p-3', 'rounded', 'text-center', 'font-medium'); 

    // Send data using 'fullName' and 'phoneNumber'
    const profileData = {
        fullName: document.getElementById('settingName').value, 
        email: document.getElementById('settingEmail').value,
        phoneNumber: document.getElementById('settingPhone').value, 
        organization: document.getElementById('settingOrganization').value, 
    };
    
    if (submitButton) {
        submitButton.disabled = true;
        submitButton.textContent = 'Saving...';
    }

    try {
        const response = await fetch('/api/user/settings/profile', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(profileData)
        });

        if (response.ok) {
            messageEl.textContent = '✅ Profile updated successfully!';
            messageEl.classList.remove('bg-red-200', 'text-red-700');
            messageEl.classList.add('bg-green-200', 'text-green-700');
            loadUserSettings(); // Refresh the welcome message
        } else {
            let errorText = 'Unknown Error.';
            
            if (response.status === 404) {
                errorText = "Not Found (404). Check your backend server routes for POST /api/user/settings/profile!";
            } else {
                try {
                    const errorJson = await response.json();
                    errorText = errorJson.message || `Server responded with status ${response.status}`;
                } catch {
                    errorText = `Server responded with status ${response.status}`;
                }
            }
            
            console.error('Profile update failed. Server response:', response.status, errorText);
            messageEl.textContent = `❌ Error updating profile: ${errorText}`;
            messageEl.classList.remove('bg-green-200', 'text-red-700');
            messageEl.classList.add('bg-red-200', 'text-red-700');
        }

    } catch (error) {
        console.error('Profile update failed (Network/Catch):', error);
        messageEl.textContent = '❌ Network Error: Could not connect to server.';
        messageEl.classList.remove('bg-green-200', 'text-red-700');
        messageEl.classList.add('bg-red-200', 'text-red-700');
    } finally {
        messageEl.style.display = 'block';
        if (submitButton) {
            submitButton.disabled = false;
            submitButton.textContent = 'Save Profile Settings';
        }
    }
}

/**
 * Utility function to inject the message element if it doesn't exist.
 */
function createMessageElement(form, id) {
    const el = document.createElement('div');
    el.id = id;
    form.parentNode.insertBefore(el, form.nextSibling);
    return el;
}