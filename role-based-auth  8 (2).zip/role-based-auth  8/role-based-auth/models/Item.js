const mongoose = require('mongoose');   // ✅ Add this line at the very top

const ItemSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true,
        trim: true,
    },
    description: {
        type: String,
        required: false,
    },
    location: {
        type: String,
        required: true,
    },
    contact: {
        type: String,
        required: false,
    },
    date: {
        type: Date,
        required: true,
    },
    isClaimed: {
        type: Boolean,
        default: false,
    },
    reportedAt: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model('Item', ItemSchema);
