/**
 * Express Server Setup
 * Ensures correct middleware ordering to prevent route-handling hangs.
 */
require('dotenv').config();
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');

const connectDB = require('./config/db');

// Import Routes
const authRoutes = require('./routes/auth');
const protectedRoutes = require('./routes/protected');
const userRoutes = require('./routes/user');
const adminRoutes = require('./routes/admin');
const itemRoutes = require('./routes/itemRoutes');

const app = express(); // ✅ Define app BEFORE using it

// 1. Body Parsers
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// 2. Cookie parser
app.use(cookieParser());

// 3. Connect DB
connectDB().catch(err => {
  console.error('❌ DB connection failed', err);
  process.exit(1);
});

// 4. Serve frontend (static files)
app.use(express.static(path.join(__dirname, 'public')));

// 5. API Routes
app.use('/api/auth', authRoutes);
app.use('/api/protected', protectedRoutes);
app.use('/api/user', userRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/items', itemRoutes); // ✅ correct placement

// 6. Fallback route
app.use((req, res) => res.status(404).send({ message: 'Not found' }));

// 7. Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
