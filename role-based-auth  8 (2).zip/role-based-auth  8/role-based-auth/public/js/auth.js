// public/js/auth.js
async function postJSON(path, data) {
  const res = await fetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify(data)
  });
  let json;
  try { json = await res.json(); } catch(e) { json = { message: 'No JSON response' }; }
  return { status: res.status, ok: res.ok, body: json };
}

function $id(id){ return document.getElementById(id); }

const outElem = document.getElementById('out');

if (document.getElementById('registerForm')) {
  const form = document.getElementById('registerForm');
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(form);
    const name = fd.get('name'),
          email = fd.get('email'),
          password = fd.get('password'),
          role = fd.get('role');

    let r;
    if (role === 'Admin') {
      const adminSecret = fd.get('adminSecret') || prompt('Admin secret required:');
      r = await postJSON('/api/auth/register/admin', { name, email, password, adminSecret });
    } else {
      r = await postJSON('/api/auth/register/user', { name, email, password });
    }

    // ✅ Success/Error UI handling
    let outBox = document.getElementById("out");
    if (r.ok && r.body.success !== false) {
      outBox.innerText = "✅ User registered successfully!";
      outBox.className = "show success";
    } else {
      outBox.innerText = "❌ " + (r.body.message || "Something went wrong");
      outBox.className = "show error";
    }
  });
}

// ✅ LOGIN SECTION FIXED BELOW
if (document.getElementById('loginForm')) {
  const form = document.getElementById('loginForm');
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(form);

    // Get selected role correctly (use your radio buttons)
    const role = fd.get('type') || fd.get('role') || 'user';
    const email = fd.get('email');
    const password = fd.get('password');

    // Decide API route based on role
    const path = role === 'admin' ? '/api/auth/login/admin' : '/api/auth/login/user';
    const r = await postJSON(path, { email, password });
    outElem.textContent = r.body.message || JSON.stringify(r.body);

    if (r.ok) {
      // ✅ Redirect to correct page based on role
      if (role === 'admin') {
        window.location.href = "admin.html";  // 👈 Admin dashboard
      } else {
        window.location.href = "user-dashboard.html"; // 👈 User dashboard
      }

      // Optional: Add a "Get My Profile" button (only after redirect)
      const btn = document.createElement('button');
      btn.textContent = 'Get My Profile';
      btn.style.marginTop = '10px';
      btn.onclick = async () => {
        const pr = await fetch('/api/protected/me', { credentials: 'include' });
        const pj = await pr.json();
        outElem.textContent = JSON.stringify(pj, null, 2);
      };
      outElem.appendChild(document.createElement('br'));
      outElem.appendChild(btn);
    }
  });
}

// Forgot Password Section
if (document.getElementById("forgotForm")) {
  const form = document.getElementById("forgotForm");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = e.target.email.value;

    const res = await fetch("/api/auth/forgot-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });

    const data = await res.json();

    if (data.redirect) {
      window.location.href = data.redirect;
    } else {
      document.getElementById("out").innerText =
        data.message || "Check your email for reset link";
    }
  });
}

// Reset Password Section
if (document.getElementById('resetForm')) {
  const form = document.getElementById('resetForm');
  const outElem = document.getElementById('out');
  const params = new URLSearchParams(location.search);
  const token = params.get('token');

  form.addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(form);
    const password = fd.get('password');

    if (!token) {
      outElem.textContent = '❌ No token in URL';
      outElem.className = "show error";
      return;
    }

    const r = await postJSON('/api/auth/reset-password/' + token, { password });

    if (r.ok) {
      outElem.textContent = "✅ Password updated successfully!";
      outElem.className = "show success";
      setTimeout(() => location.href = '/login.html', 2000);
    } else {
      outElem.textContent = "❌ " + (r.body.message || "Something went wrong");
      outElem.className = "show error";
    }
  });
}
