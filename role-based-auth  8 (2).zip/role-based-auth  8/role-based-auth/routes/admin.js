const express = require('express');
const router = express.Router();
const Item = require('../models/Item'); // Import your Item model
const User = require('../models/User'); // Import your User model

// ✅ GET all items
router.get('/items', async (req, res) => {
  try {
    const items = await Item.find();
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch items' });
  }
});

// ✅ GET all users
router.get('/users', async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

// ✅ Approve item
router.put('/items/:id/approve', async (req, res) => {
  try {
    const item = await Item.findByIdAndUpdate(req.params.id, { status: 'Approved' }, { new: true });
    res.json(item);
  } catch (err) {
    res.status(500).json({ error: 'Failed to approve item' });
  }
});

// ✅ Delete item
router.delete('/items/:id', async (req, res) => {
  try {
    await Item.findByIdAndDelete(req.params.id);
    res.json({ message: 'Item deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete item' });
  }
});

module.exports = router;
