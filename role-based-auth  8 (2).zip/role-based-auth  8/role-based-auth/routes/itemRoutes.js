const express = require('express');
const router = express.Router();
const Item = require('../models/Item'); // make sure the path is correct

// ✅ GET all items (for admin dashboard)
router.get('/', async (req, res) => {
  try {
    const items = await Item.find().sort({ reportedAt: -1 }); // newest first
    res.json(items);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ✅ Approve an item (mark as claimed)
router.put('/:id/approve', async (req, res) => {
  try {
    const item = await Item.findByIdAndUpdate(req.params.id, { isClaimed: true });
    if (!item) return res.status(404).json({ message: 'Item not found' });
    res.json({ message: 'Item approved successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ✅ Delete an item
router.delete('/:id', async (req, res) => {
  try {
    const item = await Item.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ message: 'Item not found' });
    res.json({ message: 'Item deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
