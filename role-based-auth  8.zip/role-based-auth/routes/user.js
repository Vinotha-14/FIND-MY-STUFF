/**
 * User Routes Module (POST /report and GET /items, POST /claim)
 * This version uses Mongoose for permanent storage, filtering, and status updates.
 */
const express = require('express');
const router = express.Router();
const Item = require('../models/Item'); 

/**
 * POST /api/user/report
 * Endpoint to permanently store the lost item report in the database.
 */
router.post('/report', async (req, res) => {
    // Logging placed at the absolute top of the route execution
    console.log('--- REPORT ENDPOINT HIT (MongoDB Save) ---'); 

    // Destructure required fields from the request body
    const { title, description, location, contact, date } = req.body;
    
    // Basic validation
    if (!title || !location || !date) {
        console.warn('Validation Failed: Missing required fields.');
        return res.status(400).json({ message: 'Missing required item details (Title, Location, and Date are mandatory).' });
    }

    try {
        let submissionDate = null;
        try {
            submissionDate = new Date(date);
            // Check if the date conversion resulted in a valid date
            if (isNaN(submissionDate.getTime())) {
                throw new Error("Invalid date format received.");
            }
        } catch (dateError) {
            console.error('Date parsing failed:', dateError.message);
            // Return 400 if the date is invalid, preventing Mongoose crash
            return res.status(400).json({ message: 'Invalid date format submitted.' });
        }


        // Log data *before* database operation
        console.log('Data received (pre-db):', { title, description, location, contact, date: submissionDate });
        
        // Create a new item document in MongoDB
        const newReport = await Item.create({
            title,
            description,
            location,
            contact,
            date: submissionDate, // Use the validated Date object
        });

        console.log(`Report saved successfully. Item ID: ${newReport._id}`);
        
        // Respond with success message
        res.status(201).json({ 
            message: 'Item report received and saved successfully!',
            itemId: newReport._id 
        });

    } catch (error) {
        // Handle database errors or unexpected crashes
        // Log the error using bright red text for maximum visibility in the console
        console.error('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
        console.error('!!! SERVER CRASH LIKELY HERE: CRITICAL DB ERROR PROCESSING REPORT !!!');
        console.error('!!! ERROR:', error.message);
        console.error('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
        
        // This is what the client receives if the server crashes
        res.status(500).json({ message: `Internal server error during save: ${error.message}` });
    }
});

/**
 * POST /api/user/claim/:id
 * Endpoint to toggle the 'isClaimed' status of a specific item.
 * Requires the item ID in the URL and the new boolean status in the body.
 */
router.post('/claim/:id', async (req, res) => {
    try {
        const itemId = req.params.id;
        const { isClaimed } = req.body; // Expecting a boolean (true/false)

        if (typeof isClaimed !== 'boolean') {
            return res.status(400).json({ message: 'Invalid claim status provided (must be boolean).' });
        }
        
        // Find the item by ID and update the isClaimed status
        const updatedItem = await Item.findByIdAndUpdate(
            itemId,
            { isClaimed },
            { new: true } // Returns the updated document
        );

        if (!updatedItem) {
            return res.status(404).json({ message: 'Item not found.' });
        }

        res.status(200).json({ 
            message: `Item status updated to claimed: ${updatedItem.isClaimed}`,
            item: {
                id: updatedItem._id,
                isClaimed: updatedItem.isClaimed
            }
        });

    } catch (error) {
        console.error('CRITICAL DB ERROR processing claim update:', error.message);
        res.status(500).json({ message: `Internal server error during claim update: ${error.message}` });
    }
});


/**
 * GET /api/user/items
 * Endpoint to retrieve and filter reported items from the database.
 */
router.get('/items', async (req, res) => {
    console.log('--- ITEMS ENDPOINT HIT (MongoDB Fetch) ---');
    
    try {
        const { query } = req.query; // Get the search term from the URL query parameters
        let filter = {};

        if (query) {
            console.log(`Filtering items by search term: "${query}"`);
            
            // Create a MongoDB filter using $regex for case-insensitive partial matching
            const searchRegex = new RegExp(query, 'i');
            
            // Search across the title and location fields
            filter = {
                $or: [
                    { title: { $regex: searchRegex } },
                    { location: { $regex: searchRegex } }
                ]
            };
        }

        // Retrieve items from the database, applying the filter and sorting by newest first
        const items = await Item.find(filter).sort({ reportedAt: -1 });

        console.log(`Serving ${items.length} items from MongoDB.`);
        
        // Map Mongoose documents to plain objects for the client
        const sanitizedItems = items.map(item => ({
            id: item._id, 
            title: item.title,
            description: item.description,
            location: item.location,
            contact: item.contact,
            isClaimed: item.isClaimed || false, // <-- NEW: Include claim status
            // Format the date for cleaner display on the client side
            date: item.date ? item.date.toISOString().split('T')[0] : 'N/A' 
        }));

        res.status(200).json(sanitizedItems);

    } catch (error) {
        // Handle database errors or unexpected crashes
        console.error('SERVER CATCH: Critical DB Error fetching reports:', error.message, error.stack);
        res.status(500).json({ message: `Internal server error during fetch: ${error.message}` });
    }
});


module.exports = router;
