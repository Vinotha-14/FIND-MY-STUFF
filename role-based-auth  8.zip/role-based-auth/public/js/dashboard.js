/**
 * Client-side script for the User Dashboard (Find My Stuff)
 * This script handles:
 * 1. Navigation between dashboard sections and visual highlighting.
 * 2. Intercepting the Report Lost Item form submission (POST /api/user/report).
 * 3. Fetching and displaying reported items in the Search Items section (GET /api/user/items?query=...).
 * 4. Handling the Claim Items list and status toggling (POST /api/user/claim/:id).
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initial Setup: Show the default section and highlight the button
    // We get the default button element by ID to pass to showSection
    const initialButton = document.getElementById('nav-report');
    showSection('report', initialButton);
    
    // 2. Set up the Form Submission Listener
    const reportForm = document.getElementById('reportForm');
    if (reportForm) {
        // Input names are now handled correctly in the HTML
        reportForm.addEventListener('submit', handleReportSubmission);
    }
    
    // 3. Add event listener to the Search button
    const searchButton = document.querySelector('#search button');
    if(searchButton) {
        searchButton.addEventListener('click', searchItems);
    }
});

/**
 * Handles navigation between dashboard sections and updates active button styles.
 * @param {string} sectionId - The ID of the section to show.
 * @param {HTMLElement | null} activeButton - The navigation button element that was clicked.
 */
function showSection(sectionId, activeButton = null) {
    // 1. Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.style.display = 'none';
    });
    const target = document.getElementById(sectionId);
    if (target) {
        target.style.display = 'block';
    }
    
    // 2. Update Nav Button Styles (Tailwind classes)
    document.querySelectorAll('#mainNav button').forEach(button => {
        // Reset all buttons to inactive style
        button.classList.remove('bg-blue-600', 'text-white', 'hover:bg-blue-700');
        button.classList.add('bg-gray-200', 'text-gray-700', 'hover:bg-gray-300');
    });

    if (activeButton) {
        // Set the active button style
        activeButton.classList.remove('bg-gray-200', 'text-gray-700', 'hover:bg-gray-300');
        activeButton.classList.add('bg-blue-600', 'text-white', 'hover:bg-blue-700');
    }
    
    // 3. Trigger content loads based on section
    if (sectionId === 'claim') {
        loadClaimItems();
    }
    if (sectionId === 'search') {
        // Optionally load the full list immediately when clicking Search
        // searchItems();
    }
}

/**
 * Handles the API call for reporting a lost item.
 * @param {Event} event - The submission event.
 */
async function handleReportSubmission(event) {
    event.preventDefault(); 

    const form = event.target;
    // Utility function to get or create a message element
    const messageEl = document.getElementById('reportMessage') || createMessageElement(form, 'reportMessage');
    
    messageEl.style.display = 'none';
    messageEl.classList.add('mt-4', 'p-3', 'rounded', 'text-center', 'font-medium'); // Apply Tailwind classes for styling

    // Collect data using the actual element IDs/names
    const itemData = {
        title: document.getElementById('itemTitle').value, 
        description: document.getElementById('description').value,
        location: document.getElementById('location').value,
        contact: document.getElementById('contact').value, 
        date: document.getElementById('date').value,
    };

    try {
        const response = await fetch('/api/user/report', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(itemData)
        });

        if (response.ok) {
            const result = await response.json();
            messageEl.textContent = '✅ Item successfully reported! ID: ' + result.itemId;
            messageEl.classList.remove('bg-red-200', 'text-red-700');
            messageEl.classList.add('bg-green-200', 'text-green-700');
            form.reset(); 
            searchItems(); // Refresh the search list 
        } else {
            // Handle specific server-side errors (400, 500)
            let errorText = 'Unknown Error.';
            try {
                const errorJson = await response.json();
                errorText = errorJson.message || `Server responded with status ${response.status}`;
            } catch {
                errorText = `Server responded with status ${response.status}`;
            }
            
            console.error('Submission failed. Server response:', response.status, errorText);
            messageEl.textContent = `❌ Error: ${errorText}`;
            messageEl.classList.remove('bg-green-200', 'text-green-700');
            messageEl.classList.add('bg-red-200', 'text-red-700');
        }

    } catch (error) {
        if (!messageEl.textContent.startsWith('❌ Error:')) {
            console.error('Submission failed (Network/Catch):', error);
            messageEl.textContent = '❌ Network Error: Could not connect to server.';
            messageEl.classList.remove('bg-green-200', 'text-green-700');
            messageEl.classList.add('bg-red-200', 'text-red-700');
        }
    } finally {
        messageEl.style.display = 'block';
    }
}

/**
 * Fetches and displays reported items in the Search Items section, filtering by search query.
 */
async function searchItems() {
    const resultsDiv = document.getElementById('results');
    const searchQuery = document.getElementById('searchQuery').value.trim();
    
    // Construct the API URL with the query parameter if a search term exists
    const apiUrl = searchQuery ? `/api/user/items?query=${encodeURIComponent(searchQuery)}` : '/api/user/items';

    resultsDiv.innerHTML = '<p class="text-center text-gray-500 py-4">Searching for items...</p>';
    
    try {
        const response = await fetch(apiUrl);
        if (!response.ok) {
            throw new Error('Failed to fetch items.');
        }

        const items = await response.json();

        if (items.length === 0) {
            resultsDiv.innerHTML = `<p class="text-center text-gray-400 py-4">No lost items found matching "${searchQuery}".</p>`;
            return;
        }
        
        // Render results as stylized cards (using Tailwind for style)
        resultsDiv.innerHTML = items.map(item => `
            <div class="item-card bg-white p-4 rounded-xl shadow-md border-l-4 ${item.isClaimed ? 'border-green-500' : 'border-red-500'}">
                <div class="flex justify-between items-center mb-2">
                    <h3 class="text-xl font-bold text-gray-800">${item.title}</h3>
                    <span class="text-sm font-semibold ${item.isClaimed ? 'text-green-600' : 'text-red-600'}">
                        ${item.isClaimed ? 'CLAIMED' : 'UNCLAIMED'}
                    </span>
                </div>
                <p class="text-sm text-gray-600 mb-1"><strong>📍 Location:</strong> ${item.location}</p>
                <p class="text-sm text-gray-600 mb-1"><strong>📞 Contact:</strong> ${item.contact || 'N/A'}</p>
                <p class="text-sm text-gray-600"><strong>📅 Date Lost:</strong> ${item.date}</p>
                <p class="text-xs text-gray-500 italic mt-2">Description: ${item.description || 'No description provided.'}</p>
            </div>
        `).join('');

    } catch (error) {
        console.error('Error fetching items:', error);
        resultsDiv.innerHTML = '<p class="text-center text-red-500 py-4">Error loading items. Please check server status.</p>';
    }
}

/**
 * Fetches and displays reported items specifically for the Claim/Manage section.
 */
async function loadClaimItems() {
    const claimListDiv = document.getElementById('claimList');
    claimListDiv.innerHTML = '<p class="text-center text-gray-500 py-4">Loading reported items...</p>';

    try {
        // Fetch all items (no query parameter needed for management)
        const response = await fetch('/api/user/items');
        if (!response.ok) {
            throw new Error('Failed to fetch items for claiming.');
        }

        const items = await response.json();

        if (items.length === 0) {
            claimListDiv.innerHTML = `<p class="text-center text-gray-400 py-4">No items have been reported yet.</p>`;
            return;
        }
        
        // Render results as cards with claim toggle
        claimListDiv.innerHTML = items.map(item => `
            <div id="item-${item.id}" class="item-card flex flex-col md:flex-row justify-between items-start md:items-center bg-white p-4 rounded-xl shadow border-l-4 ${item.isClaimed ? 'border-green-500' : 'border-red-500'}">
                <div class="flex-grow mb-3 md:mb-0">
                    <h3 class="text-lg font-bold text-gray-800">${item.title}</h3>
                    <p class="text-xs text-gray-500">ID: ${item.id}</p>
                    <p class="text-sm text-gray-600 mt-1">📍 ${item.location} | 📅 ${item.date}</p>
                </div>
                
                <div class="claim-status-group flex flex-col items-start md:items-end space-y-2">
                    <span id="status-label-${item.id}" class="text-sm font-extrabold ${item.isClaimed ? 'text-green-600' : 'text-red-600'}">
                        ${item.isClaimed ? 'CLAIMED' : 'UNCLAIMED'}
                    </span>
                    <button 
                        data-id="${item.id}" 
                        data-claimed="${item.isClaimed}"
                        onclick="toggleClaimStatus('${item.id}', ${item.isClaimed})"
                        class="py-2 px-4 rounded-lg font-semibold text-white transition duration-150 shadow-md 
                        ${item.isClaimed ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600'}">
                        ${item.isClaimed ? 'Mark as UNCLAIMED' : 'Mark as CLAIMED'}
                    </button>
                </div>
            </div>
        `).join('');

    } catch (error) {
        console.error('Error fetching items for claiming:', error);
        claimListDiv.innerHTML = '<p class="text-center text-red-500 py-4">Error loading claim list. Please check server status.</p>';
    }
}

/**
 * Toggles the 'isClaimed' status of an item via a POST request to the server.
 * @param {string} itemId - The MongoDB ID of the item.
 * @param {boolean} currentStatus - The current claim status.
 */
async function toggleClaimStatus(itemId, currentStatus) {
    const newStatus = !currentStatus;
    const button = document.querySelector(`button[data-id="${itemId}"]`);
    const statusLabel = document.getElementById(`status-label-${itemId}`);

    if (button) {
        button.disabled = true; // Disable button during API call
        button.textContent = 'Updating...';
    }

    try {
        const response = await fetch(`/api/user/claim/${itemId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ isClaimed: newStatus })
        });

        if (response.ok) {
            // Update UI based on successful response
            const responseData = await response.json();
            const claimed = responseData.item.isClaimed;

            if (button) {
                button.setAttribute('data-claimed', claimed);
                button.textContent = claimed ? 'Mark as UNCLAIMED' : 'Mark as CLAIMED';
                
                // Toggle Tailwind classes for color change
                if (claimed) {
                    button.classList.remove('bg-green-500', 'hover:bg-green-600');
                    button.classList.add('bg-red-500', 'hover:bg-red-600');
                } else {
                    button.classList.remove('bg-red-500', 'hover:bg-red-600');
                    button.classList.add('bg-green-500', 'hover:bg-green-600');
                }
            }
            if (statusLabel) {
                statusLabel.textContent = claimed ? 'CLAIMED' : 'UNCLAIMED';
                
                // Toggle Tailwind classes for color change
                if (claimed) {
                    statusLabel.classList.remove('text-red-600');
                    statusLabel.classList.add('text-green-600');
                } else {
                    statusLabel.classList.remove('text-green-600');
                    statusLabel.classList.add('text-red-600');
                }
            }
            // Also update the card's border color to reflect the change
            const card = document.getElementById(`item-${itemId}`);
             if (card) {
                card.classList.remove('border-green-500', 'border-red-500');
                card.classList.add(claimed ? 'border-green-500' : 'border-red-500');
            }


        } else {
            const error = await response.json();
            console.error('Failed to update status:', error.message);
            // Log error message instead of alert()
            console.error(`ERROR: Failed to update status: ${error.message}`); 
        }
    } catch (error) {
        console.error('Network error during status toggle:', error);
         // Log error message instead of alert()
        console.error('ERROR: Network Error: Could not connect to the server to update status.');
    } finally {
        if (button) {
            button.disabled = false;
        }
    }
}

/**
 * Utility function to inject the message element if it doesn't exist.
 */
function createMessageElement(form, id) {
    const el = document.createElement('p');
    el.id = id;
    // Insert the message element right after the form
    form.parentNode.insertBefore(el, form.nextSibling);
    return el;
}
