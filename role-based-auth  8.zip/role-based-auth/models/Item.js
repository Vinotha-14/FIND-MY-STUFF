/**
 * Mongoose Model for a Lost Item Report.
 * Defines the structure for documents in the 'items' collection.
 * Includes the 'isClaimed' status for the Claim Items module.
 */
const mongoose = require('mongoose');

const ItemSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true,
        trim: true,
    },
    description: {
        type: String,
        required: false, // Description can be optional
    },
    location: {
        type: String,
        required: true,
    },
    contact: {
        type: String,
        required: false, // Contact can be optional
    },
    date: {
        type: Date,
        required: true,
    },
    // NEW: Status to track if the item has been claimed
    isClaimed: {
        type: Boolean,
        default: false, // Default: Item is not claimed when reported
    },
    // Used for sorting: newer items appear first
    reportedAt: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model('Item', ItemSchema);
