/**
 * Express Server Setup
 * Ensures correct middleware ordering to prevent route-handling hangs.
 */
require('dotenv').config();
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser'); // Moved below body parsers

const connectDB = require('./config/db');
const authRoutes = require('./routes/auth');
const protectedRoutes = require('./routes/protected');
const userRoutes = require('./routes/user'); 

const app = express();

// 1. Body Parsers MUST come first to process incoming POST/PUT data
// Increased limit just in case, and added json() parser
app.use(express.json({ limit: '50mb' })); 
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// 2. Cookie parser (less critical, but better placed after body parsers)
app.use(cookieParser());

// Connect DB
connectDB().catch(err => {
    console.error('DB connection failed', err);
    process.exit(1);
});

// Serve frontend
app.use(express.static(path.join(__dirname, 'public')));

// 3. API Routes MUST come BEFORE the 404 fallback
app.use('/api/auth', authRoutes);
app.use('/api/protected', protectedRoutes);
app.use('/api/user', userRoutes); 

// 4. Fallback MUST come LAST
app.use((req, res) => res.status(404).send({ message: 'Not found' }));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
