// routes/admin.js

/**
 * Admin Routes Module (Example: GET /users, POST /item/approve)
 * These routes should be heavily protected, only accessible by users with the 'admin' role.
 */
const express = require('express');
const router = express.Router();
const Item = require('../models/Item');
const User = require('../models/User');

// 🚨 CRITICAL: You MUST create this new middleware!
// This middleware must check if the user is logged in AND has the role 'admin'.
const { protectAdmin } = require('../middleware/auth'); // 💡 CHECK THIS PATH

// ==========================================================
// ADMIN DASHBOARD ROUTES
// ==========================================================

/**
 * GET /api/admin/dashboard-stats
 * Example: Load data for the admin dashboard overview.
 */
router.get('/dashboard-stats', protectAdmin, async (req, res) => {
    try {
        // Example logic: Fetch total counts for items and users
        const totalItems = await Item.countDocuments();
        const claimedItems = await Item.countDocuments({ isClaimed: true });
        const totalUsers = await User.countDocuments();

        res.status(200).json({
            totalItems,
            claimedItems,
            totalUsers,
            message: 'Admin dashboard stats loaded successfully.'
        });
    } catch (error) {
        console.error('Error fetching admin stats:', error.message);
        res.status(500).json({ message: 'Internal server error while loading admin stats.' });
    }
});

/**
 * GET /api/admin/users
 * ENDPOINT FOR 'USER DETAILS' TAB
 * Fetches all registered users with search functionality.
 * Query parameters:
 * - search: search term for name or email
 */
router.get('/users', protectAdmin, async (req, res) => {
    try {
        const { search } = req.query;
        
        // Build search query
        let searchQuery = {};
        if (search && search.trim()) {
            const searchRegex = new RegExp(search.trim(), 'i');
            searchQuery = {
                $or: [
                    { fullName: { $regex: searchRegex } },
                    { email: { $regex: searchRegex } },
                    { phoneNumber: { $regex: searchRegex } },
                    { organization: { $regex: searchRegex } }
                ]
            };
        }
        
        // Fetch users, excluding password hash but including roles
        const users = await User.find(searchQuery)
            .select('-password -resetPasswordToken -resetPasswordExpires -__v')
            .sort({ createdAt: -1 });

        res.status(200).json(users);
    } catch (error) {
        console.error('Error fetching users:', error.message);
        res.status(500).json({ message: 'Internal server error while fetching users.' });
    }
});

/**
 * GET /api/admin/users/:id
 * Get detailed information for a specific user
 */
router.get('/users/:id', protectAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        
        // Fetch user with all details except sensitive data
        const user = await User.findById(id)
            .select('-password -resetPasswordToken -resetPasswordExpires');
            
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        
        // Get additional statistics for this user
        const userStats = {
            totalReports: await Item.countDocuments({ reporterId: id }),
            claimedReports: await Item.countDocuments({ reporterId: id, isClaimed: true }),
            pendingReports: await Item.countDocuments({ reporterId: id, isClaimed: false })
        };
        
        // Get recent reports by this user
        const recentReports = await Item.find({ reporterId: id })
            .sort({ reportedAt: -1 })
            .limit(5)
            .select('title location isClaimed reportedAt');
        
        res.status(200).json({
            user,
            stats: userStats,
            recentReports
        });
    } catch (error) {
        console.error('Error fetching user details:', error.message);
        res.status(500).json({ message: 'Internal server error while fetching user details.' });
    }
});

// ----------------------------------------------------------
/**
 * 💡 NEW ENDPOINT: GET /api/admin/items
 * ENDPOINT FOR 'MANAGE ITEMS' TAB
 * Fetches all reported items with optional status filtering
 * Query parameters:
 * - filter: 'all', 'claimed', 'pending'
 */
router.get('/items', protectAdmin, async (req, res) => {
    try {
        const { filter = 'all' } = req.query;
        
        // Build filter query based on request parameter
        let filterQuery = {};
        if (filter === 'claimed') {
            filterQuery.isClaimed = true;
        } else if (filter === 'pending') {
            filterQuery.isClaimed = false;
        }
        // For 'all' or any other value, no filter is applied

        // Fetch items based on filter. Use .populate() to get user details linked by 'reporterId'.
        const items = await Item.find(filterQuery)
            .populate('reporterId', 'fullName email')
            .sort({ reportedAt: -1 });

        res.status(200).json(items);
    } catch (error) {
        console.error('Error fetching filtered items:', error.message);
        res.status(500).json({ message: 'Internal server error while fetching items.' });
    }
});
// ----------------------------------------------------------

/**
 * GET /api/admin/items/report
 * Generate PDF report for items based on filter
 * Query parameters:
 * - filter: 'all', 'claimed', 'pending'
 */
router.get('/items/report', protectAdmin, async (req, res) => {
    try {
        const { filter = 'all' } = req.query;
        
        // Build filter query
        let filterQuery = {};
        if (filter === 'claimed') {
            filterQuery.isClaimed = true;
        } else if (filter === 'pending') {
            filterQuery.isClaimed = false;
        }

        // Fetch items for report
        const items = await Item.find(filterQuery)
            .populate('reporterId', 'fullName email')
            .sort({ reportedAt: -1 });

        // Generate report data
        const reportData = {
            title: `Items Report - ${filter.charAt(0).toUpperCase() + filter.slice(1)}`,
            generatedAt: new Date().toISOString(),
            totalItems: items.length,
            items: items.map(item => ({
                id: item._id.toString().slice(-6),
                title: item.title,
                description: item.description,
                location: item.location,
                contact: item.contact,
                reporterName: item.reporterName,
                reporterEmail: item.reporterId ? item.reporterId.email : 'N/A',
                status: item.isClaimed ? 'Claimed' : 'Pending',
                reportedAt: item.reportedAt ? item.reportedAt.toISOString().split('T')[0] : 'N/A',
                dateLost: item.date ? item.date.toISOString().split('T')[0] : 'N/A'
            }))
        };

        res.status(200).json(reportData);
    } catch (error) {
        console.error('Error generating report:', error.message);
        res.status(500).json({ message: 'Internal server error while generating report.' });
    }
});

/**
 * PUT /api/admin/items/:id/status
 * Update item claim status
 */
router.put('/items/:id/status', protectAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const { isClaimed } = req.body;
        
        const updatedItem = await Item.findByIdAndUpdate(
            id,
            { isClaimed: Boolean(isClaimed) },
            { new: true }
        );
        
        if (!updatedItem) {
            return res.status(404).json({ message: 'Item not found' });
        }
        
        res.status(200).json({
            message: 'Item status updated successfully',
            item: updatedItem
        });
    } catch (error) {
        console.error('Error updating item status:', error.message);
        res.status(500).json({ message: 'Internal server error while updating item status.' });
    }
});

/**
 * DELETE /api/admin/items/:id
 * Delete an item
 */
router.delete('/items/:id', protectAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        
        const deletedItem = await Item.findByIdAndDelete(id);
        
        if (!deletedItem) {
            return res.status(404).json({ message: 'Item not found' });
        }
        
        res.status(200).json({
            message: 'Item deleted successfully',
            deletedItem: {
                id: deletedItem._id,
                title: deletedItem.title
            }
        });
    } catch (error) {
        console.error('Error deleting item:', error.message);
        res.status(500).json({ message: 'Internal server error while deleting item.' });
    }
});

module.exports = router;
