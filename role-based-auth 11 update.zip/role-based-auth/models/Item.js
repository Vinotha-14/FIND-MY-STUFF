/**
 * Mongoose Model for a Lost Item Report.
 * Defines the structure for documents in the 'items' collection.
 */
const mongoose = require('mongoose');

const ItemSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true,
        trim: true,
    },
    description: {
        type: String,
        required: false,
    },
    location: {
        type: String,
        required: true,
    },
    contact: {
        type: String,
        required: false,
    },
    date: {
        type: Date,
        required: true,
    },
    // CRITICAL ADDITION: Link the item to the user who reported it
    reporterId: { 
        type: mongoose.Schema.Types.ObjectId, // Defines the field as a MongoDB ID
        ref: 'User', // 👈 REQUIRED: This tells Mongoose which model to look up (i.e., the User model)
        required: true,
    },
    // NEW: Status to track if the item has been claimed
    isClaimed: {
        type: Boolean,
        default: false, 
    },
    // Used for sorting: newer items appear first
    reportedAt: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model('Item', ItemSchema);