// routes/admin.js

/**
 * Admin Routes Module (Example: GET /users, POST /item/approve)
 * These routes should be heavily protected, only accessible by users with the 'admin' role.
 */
const express = require('express');
const router = express.Router();
const Item = require('../models/Item');
const User = require('../models/User');

// 🚨 CRITICAL: You MUST create this new middleware!
// This middleware must check if the user is logged in AND has the role 'admin'.
const { protectAdmin } = require('../middleware/auth'); // 💡 CHECK THIS PATH

// ==========================================================
// ADMIN DASHBOARD ROUTES
// ==========================================================

/**
 * GET /api/admin/dashboard-stats
 * Example: Load data for the admin dashboard overview.
 */
router.get('/dashboard-stats', protectAdmin, async (req, res) => {
    try {
        // Example logic: Fetch total counts for items and users
        const totalItems = await Item.countDocuments();
        const claimedItems = await Item.countDocuments({ isClaimed: true });
        const totalUsers = await User.countDocuments();

        res.status(200).json({
            totalItems,
            claimedItems,
            totalUsers,
            message: 'Admin dashboard stats loaded successfully.'
        });
    } catch (error) {
        console.error('Error fetching admin stats:', error.message);
        res.status(500).json({ message: 'Internal server error while loading admin stats.' });
    }
});

/**
 * GET /api/admin/users
 * ENDPOINT FOR 'USER DETAILS' TAB
 * Fetches all registered users.
 */
router.get('/users', protectAdmin, async (req, res) => {
    try {
        // Fetch all users, excluding their password hash
        const users = await User.find().select('-password -role -__v'); // Exclude more sensitive/unnecessary fields

        res.status(200).json(users);
    } catch (error) {
        console.error('Error fetching all users:', error.message);
        res.status(500).json({ message: 'Internal server error while fetching users.' });
    }
});

// ----------------------------------------------------------
/**
 * 💡 NEW ENDPOINT: GET /api/admin/items
 * ENDPOINT FOR 'MANAGE ITEMS' TAB
 * Fetches all reported items and links them to the reporter's details.
 */
router.get('/items', protectAdmin, async (req, res) => {
    try {
        // Fetch all items. Use .populate() to get user details linked by 'reporterId'.
        // We select only the 'name' and 'email' from the User model for privacy.
        const items = await Item.find()
            .populate('reporterId', 'name email') // 💡 Assuming 'reporterId' is the reference field in your Item model
            .sort({ dateReported: -1 }); // Optional: sort by newest first

        res.status(200).json(items);
    } catch (error) {
        console.error('Error fetching all items:', error.message);
        res.status(500).json({ message: 'Internal server error while fetching items.' });
    }
});
// ----------------------------------------------------------


module.exports = router;