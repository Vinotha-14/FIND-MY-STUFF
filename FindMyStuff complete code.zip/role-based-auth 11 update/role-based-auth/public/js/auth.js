// public/js/auth.js
async function postJSON(path, data) {
    const res = await fetch(path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(data)
    });
    let json;
    try { json = await res.json(); } catch(e) { json = { message: 'No JSON response' }; }
    return { status: res.status, ok: res.ok, body: json };
}

function $id(id){ return document.getElementById(id); }

const outElem = document.getElementById('out');

if (document.getElementById('registerForm')) {
    const form = document.getElementById('registerForm');
    form.addEventListener('submit', async e => {
        e.preventDefault();
        const fd = new FormData(form);
        const name = fd.get('name'),
              email = fd.get('email'),
              password = fd.get('password'),
              role = fd.get('role');

        let r;
        if (role === 'Admin') {
            const adminSecret = fd.get('adminSecret') || prompt('Admin secret required:');
            r = await postJSON('/api/auth/register/admin', { name, email, password, adminSecret });
        } else {
            r = await postJSON('/api/auth/register/user', { name, email, password });
        }

        // ✅ Success/Error UI handling
        let outBox = document.getElementById("out");
        if (r.ok && r.body.success !== false) {
            outBox.innerText = "✅ User registered successfully!";
            outBox.className = "show success";
        } else {
            outBox.innerText = "❌ " + (r.body.message || "Something went wrong");
            outBox.className = "show error";
        }
    });
}

if (document.getElementById('loginForm')) {
    const form = document.getElementById('loginForm');
    form.addEventListener('submit', async e => {
        e.preventDefault();
        const fd = new FormData(form);
        
        // ⭐ CRITICAL FIX: Explicitly check which radio button is selected.
        // This prevents the path from defaulting to '/login/user' if FormData misses the selection.
        const selectedTypeElement = document.querySelector('input[name="type"]:checked');
        const type = selectedTypeElement ? selectedTypeElement.value : 'user';

        const email = fd.get('email'), password = fd.get('password');
        
        // Path selection must correctly use the captured 'type'
        const path = type === 'admin' ? '/api/auth/login/admin' : '/api/auth/login/user';
        
        // DEBUG: Check what path is being used (Check your F12 console!)
        console.log(`Attempting login for type: ${type} at path: ${path}`); 

        const r = await postJSON(path, { email, password });
        
        // ⭐ Use the server-verified role for redirection and message
        const userRole = r.body.role || 'user'; // Default to 'user' if role is missing

        if (r.ok) {
            // Success response (Status 200)
            outElem.textContent = `✅ Logged in successfully (${userRole === 'admin' ? 'Admin' : 'User'})`;

            if (userRole === 'admin') {
                window.location.href = "admin-dashboard.html"; 
            } else {
                window.location.href = "user-dashboard.html";
            }
            
            // The rest of the success code remains for the profile button
            const btn = document.createElement('button');
            btn.textContent = 'Get My Profile';
            btn.style.marginTop = '10px';
            btn.onclick = async () => {
                const pr = await fetch('/api/protected/me', { credentials: 'include' });
                const pj = await pr.json();
                outElem.textContent = JSON.stringify(pj, null, 2);
            };
            outElem.appendChild(document.createElement('br'));
            outElem.appendChild(btn);
        } else {
            // Error response (Status 400 or 403)
            outElem.textContent = "❌ " + (r.body.message || "Login failed");
        }
    });
}

if (document.getElementById("forgotForm")) {
    const form = document.getElementById("forgotForm");
    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const email = e.target.email.value;

        const res = await fetch("/api/auth/forgot-password", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email }),
        });

        const data = await res.json();

        if (data.redirect) {
            // 🚀 Dev mode: auto redirect
            window.location.href = data.redirect;
        } else {
            document.getElementById("out").innerText =
                data.message || "Check your email for reset link";
        }
    });
}


if (document.getElementById('resetForm')) {
    const form = document.getElementById('resetForm');
    const outElem = document.getElementById('out');

    // read token from query param
    const params = new URLSearchParams(location.search);
    const token = params.get('token');

    form.addEventListener('submit', async e => {
        e.preventDefault();
        const fd = new FormData(form);
        const password = fd.get('password');

        if (!token) {
            outElem.textContent = '❌ No token in URL';
            outElem.className = "show error";
            return;
        }

        const r = await postJSON('/api/auth/reset-password/' + token, { password });
        
        // ✅ Show result message
        if (r.ok) {
            
            outElem.textContent = "✅ Password updated successfully!";
            outElem.className = "show success";

            // Redirect to login after 2s
            setTimeout(() => location.href = '/login.html', 2000);
        } else {
            outElem.textContent = "❌ " + (r.body.message || "Something went wrong");
            outElem.className = "show error";
        }
    });
}