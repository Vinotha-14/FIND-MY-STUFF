// models/User.js

// 🚨 FIX: Ensure you require mongoose here
const mongoose = require('mongoose'); 

const userSchema = new mongoose.Schema({
    fullName: { 
        type: String, 
        required: true 
    },
    email: { 
        type: String, 
        index: true, 
        required: true, 
        unique: true, 
        lowercase: true, 
        trim: true 
    },
    password: { // Storing the hash
        type: String, 
        required: true 
    },
    phoneNumber: {
        type: String,
        required: false 
    },
    organization: {
        type: String,
        required: false 
    },
    roles: { 
        type: [String], 
        default: ['User'] 
    }, 
    lastLogin: { 
        type: Date 
    },
    resetPasswordToken: String,
    resetPasswordExpires: Date
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);