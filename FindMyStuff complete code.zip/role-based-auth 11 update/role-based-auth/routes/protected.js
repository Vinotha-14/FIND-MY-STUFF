// routes/protected.js
const express = require('express');
// 🚨 FIX: Destructure 'protect' from the object and rename it to 'verifyToken'
const { protect: verifyToken } = require('../middleware/auth'); 
const User = require('../models/User');

const router = express.Router();

// GET /api/protected/me
// Now, verifyToken is the function itself, not the module object.
router.get('/me', verifyToken, async (req, res) => {
    // 💡 NOTE: Based on your User model, this should probably be .select('-password')
    // and .select('-passwordHash') if you didn't change the field name in the model.
    const user = await User.findById(req.user.id).select('-passwordHash -resetPasswordToken -resetPasswordExpires');
    
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json(user);
});

module.exports = router;