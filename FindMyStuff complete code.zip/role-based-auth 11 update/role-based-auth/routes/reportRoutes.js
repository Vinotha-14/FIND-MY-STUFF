router.post('/report', async (req, res) => {
  try {
    console.log('--- REPORT ENDPOINT HIT (MongoDB Save) ---');
    console.log('Data received (pre-db):', req.body);

    const newReport = new Report({
      title: req.body.title,
      description: req.body.description,
      location: req.body.location,
      contact: req.body.contact,
      date: req.body.date,
      reporterId: req.user.id, // ✅ automatically assign from logged-in user
    });

    await newReport.save();
    res.status(201).json({ success: true, data: newReport });
  } catch (error) {
    console.error('Critical DB error while saving report:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});
