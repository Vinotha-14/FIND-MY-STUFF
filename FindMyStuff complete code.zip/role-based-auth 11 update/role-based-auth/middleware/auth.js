// middleware/auth.js

const jwt = require('jsonwebtoken');

/**
 * Middleware to protect routes: Ensures a valid JWT is present 
 * and extracts user data (ID and roles) from it.
 */
function protect(req, res, next) {
    try {
        // 1. Check for token in cookies
        const token = req.cookies?.token;
        if (!token) {
            return res.status(401).json({ message: 'No token, authorization denied' });
        }

        // 2. Verify token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // 3. Attach user data to the request object (CRITICAL STEP)
        // Ensure the token payload includes 'id' and 'role' or 'roles'.
        req.user = { 
            id: decoded.id, 
            role: decoded.role // Assuming your token payload includes a 'role' field
        };

        // 4. Continue to the next middleware/route handler
        next();

    } catch (err) {
        // Handle verification failure (e.g., expired or malformed token)
        console.error('JWT verification failed:', err.message);
        return res.status(401).json({ message: 'Token invalid or expired' });
    }
}

// ------------------------------------------------------------------

/**
 * ⭐ NEW MIDDLEWARE: protectAdmin
 * Middleware to protect ADMIN routes: Ensures the user is logged in AND has the 'admin' role.
 * This function utilizes the 'protect' logic by calling 'next()' only if the role check passes.
 */
function protectAdmin(req, res, next) {
    // 1. First, check for a valid token and attach user info using the base 'protect' logic
    protect(req, res, () => {
        // This callback runs ONLY if 'protect' was successful and called next()

        // 2. Check the user's role
        // This relies on the 'protect' middleware having set req.user.role correctly.
        if (req.user && req.user.role === 'admin') {
            // Role check passed, continue to the route handler
            next();
        } else {
            // Role check failed (not an admin)
            return res.status(403).json({ message: 'Access denied: Admin privileges required.' });
        }
    });
}

// 💡 EXPORT BOTH MIDDLEWARE FUNCTIONS
module.exports = { protect, protectAdmin };